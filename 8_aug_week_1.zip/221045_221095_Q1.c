#include <stdio.h>
#include <stdlib.h>

int array[20], i = 0;

typedef struct Node
{
    int data;
    struct Node *right, *left;

} Node;

Node *newnode(int data)
{
    //     node = new Node
    Node *newnode;
    newnode = (Node *)malloc(sizeof(Node *));
    //     node.value = value
    newnode->data = data;
    newnode->left = NULL;
    newnode->right = NULL;
    //     node.left = null
    //     node.right = null
    //     return node
    return newnode;
}

// Node *create()
// {
//     int x;
//     Node *new_node;
//     new_node = (Node *)malloc(sizeof(Node));

//     printf("Enter data :");
//     scanf("%d", &x);
//     if (x == -1)
//     {
//         return NULL;
//     }
//     new_node->data;
//     printf("Enter the left child of %d:", x);
//     new_node->left = create();
//     rintf("Enter the right child of %d:", x);
//     new_node->right = create();
//     return new_node;
// };

Node *insert(Node *root, int x)
{
    if (root == NULL)
        return newnode(x);
    else if (x > root->data)
        root->right = insert(root->right, x);
    else
        root->left = insert(root->left, x);
    return root;
}

void Inorder(Node *root)
{
    if (root != NULL)
    {
        Inorder(root->left);
        array[i] = root->data;
        i++;
        Inorder(root->right);
    }
}

int main()
{
    Node *root;
    root = newnode(15);
    insert(root, 10);
    insert(root, 8);
    insert(root, 5);
    insert(root, 9);
    insert(root, 12);
    insert(root, 14);
    insert(root, 20);
    insert(root, 17);
    insert(root, 25);
    insert(root, 22);
    insert(root, 30);

    Inorder(root);

    printf("\nOutput array should be: ");
    for (int i = 0; i < 12; i++)
    {
        printf("%d  ", array[i]);
    }

    return 0;
}
