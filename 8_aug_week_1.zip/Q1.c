// Write a C program to create a binary search tree and perform the following listed operations,
// Insert_node()
// Search_node()
// Delete_node()
// FindHeight()
// FindSize()
// findMin()
// findMax()
// MirrorImage()

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct Node
{
    int data;
    struct Node *right, *left;

} Node;

// function create_new_node(value):
Node *newnode(int data)
{

    //     node = new Node
    Node *newnode;
    newnode = (Node *)malloc(sizeof(Node));
    //     node.value = value
    newnode->data = data;
    newnode->left = NULL;
    newnode->right = NULL;
    //     node.left = null
    //     node.right = null
    //     return node
    return newnode;
}

Node *Insert_node(Node *root, int x)
{
    if (root == NULL)
        return newnode(x);
    else if (x > root->data)
        root->right = Insert_node(root->right, x);
    else
        root->left = Insert_node(root->left, x);
    return root;
}

Node *Search_node(Node *root, int target)
{
    // if root is null or root.value == target
    if (root == NULL || root->data == target)
    {
        return root;
    }
    // return root
    if (target < root->data)
    {
        return Search_node(root->left, target);
    }
    else
    {
        return Search_node(root->right, target);
    }
}
Node *findMin(Node *root)
{
    if (root != NULL && root->left == NULL)
    {
        return root;
    }
    else
    {
        findMin(root->left);
    }
    // printf("Min : %d", root->data);
}

Node *findMax(Node *root)
{
    if (root->right == NULL)
    {
        return root;
    }
    else
    {
        findMax(root->right);
    }
}

Node *Delete_node(Node *root, int target)
{
    if (root == NULL)
    {
        printf("\nTarget is not found in the tree");
    }
    else if (target < root->data)
    {
        root->left = Delete_node(root->left, target);
    }
    else if (target > root->data)
    {
        root->right = Delete_node(root->right, target);
    }
    else
    {
        if (root->left == NULL)
        {
            Node *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            Node *temp = root->left;
            free(root);
            return temp;
        }

        Node *temp = findMin(root->right);
        root->data = temp->data;
        root->right = Delete_node(root->right, temp->data);
    }
    return root;
}

int FindHeight(Node *root)
{
    int left_height, right_height;
    if (root == NULL)
    {
        return -1;
    }
    left_height = FindHeight(root->left);
    right_height = FindHeight(root->right);
    return fmax(left_height, right_height) + 1;
}

int FindSize(Node *root)
{
    if (root == NULL)
    {
        return 0;
    }
    return FindSize(root->left) + FindSize(root->right) + 1;
}
void Inorder(Node *root)
{
    if (root != NULL)
    {
        Inorder(root->left);
        printf("%d ", root->data);
        Inorder(root->right);
    }
}

Node *MirrorImage(Node *root)
{
    if (root == NULL)
    {
        return 0;
    }
    Node *temp;
    temp = root->left;
    root->left = root->right;
    root->right = temp;
    MirrorImage(root->left);
    MirrorImage(root->right);
}

int main()
{
    Node *root;
    Node *min, *max;
    root = newnode(20);

    root = Insert_node(root, 5);
    root = Insert_node(root, 10);
    root = Insert_node(root, 12);
    root = Insert_node(root, 19);

    printf("Inorder traversal of the tree: ");
    Inorder(root);

    findMin(root);

    Node *minNode = findMin(root);
    if (minNode != NULL)
    {
        printf("\nMinimum value in the tree: %d\n", minNode->data);
    }
    else
    {
        printf("\nThe tree is empty.\n");
    }

    Node *maxNode = findMax(root);
    if (maxNode != NULL)
    {
        printf("\nMaximum value in the tree: %d\n", maxNode->data);
    }
    else
    {
        printf("\nThe tree is empty.\n");
    }

    Node *search = Search_node(root, 12);
    if (search != NULL)
    {
        printf("\nFound the Number %d\n", search->data);
    }
    else
    {
        printf("\nThe tree is empty.\n");
    }

    int height = FindHeight(root);
    printf("\nHeight of the tree: %d\n", height);

    int size = FindSize(root);
    printf("Size of the tree: %d\n", size);

    Node *delete = Delete_node(root, 5);
    if (delete != NULL)
    {
        printf("\nFound deletable number\n");
    }
    else
    {
        printf("\nThe tree is empty.\n");
    }

    printf("\nInorder traversal after deletion: ");
    Inorder(root);

    MirrorImage(root);
    printf("\nInorder traversal of the tree(Mirrored): ");
    Inorder(root);

    return 0;
}