#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

char array[50];
int i = 0;

typedef struct Node
{
    int data;
    struct Node *left, *right;
} Node;

// Function to create a new binary tree node from a given data.
Node *newNode()
{
    int x;
    Node *newcreate;
    newcreate = (Node *)malloc(sizeof(Node));
    printf("Enter data (Enter -1 if no node) :");
    scanf("%d", &x);
    if (x == -1)
    {
        return NULL;
    }
    newcreate->data = x;
    printf("Enter the left child of %d\n", x);
    newcreate->left = newNode();
    printf("Enter the right child of %d\n", x);
    newcreate->right = newNode();
    return newcreate;
}

Node *Predorder(Node *root)
{

    if (root == NULL)
    {
        array[i] = 'b';
        i++;
        return;
    }

    printf("%d - ", root->data);
    array[i] = 'l';
    i++;
    Predorder(root->left);
    array[i] = 'r';
    i++;

    Predorder(root->right);
}

// Function to determine if the tree is symmetric.
bool isMirror(Node *left, Node *right)
{
    if (left == NULL && right == NULL)
        return true;
    if (left == NULL || right == NULL)
        return false;

    return (left->data == right->data) && isMirror(left->left, right->right) && isMirror(left->right, right->left);
}

bool isSymmetric(Node *root)
{
    if (root == NULL)
        return true;

    return isMirror(root->left, root->right);
}

// bool isSymmetric(Node *root)
// {
//     printf("here the string : ");
//     for (int j = 0; j < i; j++)
//     {
//         printf("%c", array[j]);
//     }

//     int n = sizeof(array[]) / sizeof(array[0]);

//     printf("%d\n", n);

//     for (int k = 0; k < (n / 2); k++)
//     {
//         if ((array[i] == 'l' && array[i + 5] == 'r') || (array[i] == 'l' && array[i + 5] == 'l') || (array[i] == 'r' && array[i + 5] == 'l'))
//         {
//             printf("T\n");
//         }
//         else if (array[i] == array[i + 5] == 'b')
//         {
//             printf("T\n");
//         }
//     }
// }

int main()
{
    Node *root;
    printf("Preorder :");
    root = newNode();
    Predorder(root);
    if (isSymmetric(root))
    {
        printf("\nThe tree is symmetric.\n");
    }
    else
    {
        printf("\nThe tree is not symmetric.\n");
    }
    return 0;
}